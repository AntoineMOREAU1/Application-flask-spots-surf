
a=['La Couarde']

print(a)  
print(type(a))  

b="".join(a)

print(b)  
print(type(b))  