with open('spots.csv', 'r') as f: 

    r = csv.reader(f,delimiter=';')     


