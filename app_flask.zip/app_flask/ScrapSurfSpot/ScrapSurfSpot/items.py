# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy

class ArticleItem(scrapy.Item):
    name_spot = scrapy.Field()
    day_0 = scrapy.Field()
    day_1 = scrapy.Field()
    day_2 = scrapy.Field()
    day_3 = scrapy.Field()
    day_4 = scrapy.Field()
    swell_by_day = scrapy.Field()
    interval_by_day = scrapy.Field()
    vitesse_vent_by_day = scrapy.Field()
    weather_by_day = scrapy.Field()
    orientation_swell_by_day = scrapy.Field()
    orientation_wind_by_day = scrapy.Field()
    temp_air_by_day = scrapy.Field()
    swell_day_0 = scrapy.Field()
    swell_day_1 = scrapy.Field()
    swell_day_2 = scrapy.Field()
    swell_day_3 = scrapy.Field()
    swell_day_4 = scrapy.Field()
    temp_air_day_0 = scrapy.Field()
    temp_air_day_1 = scrapy.Field()
    temp_air_day_2 = scrapy.Field()
    temp_air_day_3 = scrapy.Field()
    temp_air_day_4 = scrapy.Field()
    vitesse_vent_day_0 = scrapy.Field()
    vitesse_vent_day_1 = scrapy.Field()
    vitesse_vent_day_2 = scrapy.Field()
    vitesse_vent_day_3 = scrapy.Field()
    vitesse_vent_day_4 = scrapy.Field()
    url_clean_spot = scrapy.Field()
        